USE_CHECKBOXES=false
MAIN_BUTTON_STYLE = "peace-button-style"
ITEM_BUTTON_BASE_STYLE = "peace-item-button-base"
-- in 0.1.1 style name changed to icon2 as workaround for https://forums.factorio.com/viewtopic.php?f=25&t=23968
ITEM_BUTTON_STYLE_PREFIX = (USE_CHECKBOXES and "peace-item-icons2-" or "peace-item-icons-")

MAIN_BUTTON_NAME = "peace-button"
--MAIN_FRAME_NAME = "peace-frame"
--ITEM_TABLE_NAME = "peace-item-table"
ITEM_BUTTON_NAME_PREFIX = "peace-item-button-"

