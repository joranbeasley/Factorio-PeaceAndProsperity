require("utils") -- helpers i "borrowed" from the timetools mod
require("constants")
require("prototypes.styles") -- the gui styles

--BUTTON_CLICK_SOUND_NAME = "peace-button-sound"

--[[
Go through all defined data, look for items and create styles. See comments at
top of file.
--]]

