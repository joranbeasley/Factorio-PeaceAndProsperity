require("utils") -- helpers i "borrowed" from the timetools mod
require("prototypes.styles") -- the gui styles
